package com.example.search

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.SearchView
import com.example.search.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_main)

        val restaurant = arrayOf(
            "Antonio's",
            "Bar Pintxos BGC",
            "Blackbird",
            "Bondi&Bourke",
            "China Blue",
            "Crystal Dragon",
            "Le Bar",
            "Cafe Ilang-Ilang",
            "mcDonalds",
            "KFC",
            "Jollibee",
            "Mang Inasal",
            "Andoks",
            "Burger King",
            "Baskin Robbins"
        )

        val restoAdapter: ArrayAdapter<String> = ArrayAdapter(
            this, android.R.layout.simple_list_item_1,
            restaurant
        )

        binding.searchList.adapter = restoAdapter;

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                binding.searchView.clearFocus()
                if (restaurant.contains(query)) {

                    restoAdapter.filter.filter(query)

                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                restoAdapter.filter.filter(newText)
                return false
            }


        })
    }}